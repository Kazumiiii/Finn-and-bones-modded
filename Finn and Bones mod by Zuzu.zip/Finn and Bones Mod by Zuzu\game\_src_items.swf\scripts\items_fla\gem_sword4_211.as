package items_fla
{
   import flash.display.MovieClip;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol53")]
   public dynamic class gem_sword4_211 extends MovieClip
   {
      
      public function gem_sword4_211()
      {
         super();
         addFrameScript(3,this.frame4,7,this.frame8,11,this.frame12,15,this.frame16,19,this.frame20);
      }
      
      internal function frame4() : *
      {
         stop();
      }
      
      internal function frame8() : *
      {
         stop();
      }
      
      internal function frame12() : *
      {
         stop();
      }
      
      internal function frame16() : *
      {
         stop();
      }
      
      internal function frame20() : *
      {
         stop();
      }
   }
}

